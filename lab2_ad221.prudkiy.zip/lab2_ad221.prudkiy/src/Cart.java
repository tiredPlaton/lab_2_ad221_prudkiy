import java.util.LinkedList;
import java.util.Queue;

public class Cart {
    private final Queue<Item> items;
    private final int maxSize;

    public Cart(int maxSize) {
        this.maxSize = maxSize;
        this.items = new LinkedList<>();
    }

    public boolean addItem(Item item) {
        if (items.size() < maxSize) {
            return items.add(item);
        } else {
            System.out.println("Кошик переповнений. Неможливо додати товар.");
            return false;
        }
    }

    public boolean removeItem() {
        if (!items.isEmpty()) {
            Item removedItem = items.poll();
            System.out.println("Товар '" + removedItem.getName() + "' видалено з кошика.");
            return true;
        } else {
            System.out.println("Кошик порожній. Неможливо видалити товар.");
            return false;
        }
    }

    public float calculateTotalPrice() {
        float totalPrice = 0;
        for (Item item : items) {
            totalPrice += item.getPrice();
        }
        return totalPrice;
    }

    public void increasePrices(float percent) {
        for (Item item : items) {
            item.increasePrice(percent);
        }
    }

    public void decreasePrices(float percent) {
        for (Item item : items) {
            item.decreasePrice(percent);
        }
    }
}


