public class Item {
    private final String name; // Поле для найменування товару
    private float price; // Поле для ціни товару

    // Конструктор класу, який приймає найменування та початкову ціну товару
    public Item(String name, float initialPrice) {
        this.name = name;
        if (initialPrice < 0) {
            this.price = 0; // Якщо передана негативна ціна, встановлюємо ціну в 0
        } else {
            this.price = initialPrice;
        }
    }

    // Публічний метод для підвищення ціни на певний відсоток
    // Значення відсотка типу float передається як аргумент методу
    public void increasePrice(float percent) {
        if (percent >= 0) {
            this.price += this.price * (percent / 100);
        }
    }

    // Публічний метод для зниження ціни на певний відсоток
    // Значення відсотка типу float передається як аргумент методу
    public void decreasePrice(float percent) {
        if (percent >= 0) {
            this.price -= this.price * (percent / 100);
            if (this.price < 0) {
                this.price = 0;
            }
        }
    }

    // Публічний метод для отримання ціни товару
    public float getPrice() {
        return price;
    }

    // Публічний метод для отримання найменування товару
    public String getName() {
        return name;
    }
}

