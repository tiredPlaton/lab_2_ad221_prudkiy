// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        // Створення об'єкту класу Cart з максимальною кількістю товарів у стеку 6
        Cart cart = new Cart(6);

        // Заповнення кошика об'єктами класу Item
        Item item1 = new Item("Red Bull", 22.5f);
        Item item2 = new Item("Гумка", 5.0f);
        Item item3 = new Item("Шоколод", 11.5f);
        Item item4 = new Item("Шинка", 63.0f);
        Item item5 = new Item("Кефір", 15.0f);
        Item item6 = new Item("Чай", 9.5f);

        cart.addItem(item1);
        cart.addItem(item2);
        cart.addItem(item3);
        cart.addItem(item4);
        cart.addItem(item5);
        cart.addItem(item6);

        // Виведення суми цін товарів усередині кошика
        float totalPrice = cart.calculateTotalPrice();
        System.out.println("Сума цін товарів у кошику: " + totalPrice);

        // Підвищення цін у кошику на 15%
        cart.increasePrices(15);

        // Виведення зміненої суми цін після підвищення
        totalPrice = cart.calculateTotalPrice();
        System.out.println("Змінена сума цін після підвищення: " + totalPrice);

        // Зниження цін у кошику на 30%
        cart.decreasePrices(30);

        // Виведення зміненої суми цін після зниження
        totalPrice = cart.calculateTotalPrice();
        System.out.println("Змінена сума цін після зниження: " + totalPrice);
    }
}



